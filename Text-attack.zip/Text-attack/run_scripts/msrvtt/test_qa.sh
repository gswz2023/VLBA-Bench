
checkpoint_path="lavis/output/msrvtt_qa/blip2_vicuna_instruct_vicuna7b/train/b32_e5_lr0.0001_wd0.05_q32_f20_fb10_freezevit/checkpoint_best.pth"
torchrun --nproc_per_node=4 \
    --master_port=34650 \
    train.py \
    --cfg-path lavis/projects/malmm/qa_msrvtt.yaml \
    --options \
    model.arch blip2_vicuna_instruct \
    model.model_type vicuna7b \
    model.load_finetuned False \
    model.load_pretrained True \
    model.num_query_token 32 \
    model.vit_precision fp16 \
    model.freeze_vit True \
    model.memory_bank_length 10 \
    model.num_frames 20 \
    run.init_lr 1e-4 \
    run.max_epoch 5 \
    run.num_beams 5 \
    run.batch_size_train 16 \
    run.batch_size_eval 16 \
    run.accum_grad_iters 2 \
    run.num_workers 1 \
    run.seed 42 \
    run.evaluate True \
    run.valid_splits "['val', 'test']" \
    run.report_metric True \
    run.prefix test \
    run.resume_ckpt_path ${checkpoint_path}

